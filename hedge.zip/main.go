/**
 * @Author $
 * @Description //TODO $
 * @Date $ $
 * @Param $
 * @return $
 **/
package main

import "github.com/wangyi/GinTemplate/cmd"

func main() {
	cmd.Execute()
}
