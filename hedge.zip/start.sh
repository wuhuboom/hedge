go build main.go

./main server -d